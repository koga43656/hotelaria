function carregarUsuarios() {
    return JSON.parse(localStorage.getItem("usuarios")) || [];
}

function atualizarTabelaUsuarios() {
    const usuarios = carregarUsuarios();
    const tabelaBody = document.getElementById("listaUsuarios").getElementsByTagName("tbody")[0];
    tabelaBody.innerHTML = ""; 

    usuarios.forEach((usuario, index) => {
        const row = tabelaBody.insertRow();

       
        row.insertCell(0).innerText = usuario.nome;   
        row.insertCell(1).innerText = usuario.email;  
        row.insertCell(2).innerText = usuario.id;    
        row.insertCell(3).innerText = usuario.endereco; 

       

    });
}


window.onload = atualizarTabelaUsuarios;