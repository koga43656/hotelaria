let produtosFrigobar = JSON.parse(localStorage.getItem("produtosFrigobar")) || [];
let comprasHospede = [];
let totalCompras = 0;

function carregarFrigobar() {
    const tabela = document.getElementById("listaFrigobar").getElementsByTagName("tbody")[0];
    tabela.innerHTML = "";
    produtosFrigobar.forEach((produto) => {
        const row = tabela.insertRow();
        row.insertCell(0).innerText = produto.id;
        row.insertCell(1).innerText = produto.nome;
        row.insertCell(2).innerText = `R$ ${produto.preco.toFixed(2)}`;
        const acaoCell = row.insertCell(3);
        const botaoComprar = document.createElement("button");
        botaoComprar.innerText = "Comprar";
        botaoComprar.onclick = () => comprarItem(produto);
        acaoCell.appendChild(botaoComprar);
    });
}

function comprarItem(produto) {
    comprasHospede.push(produto);
    totalCompras += produto.preco;
    atualizarCompras();
}

function atualizarCompras() {
    const listaCompras = document.getElementById("listaCompras");
    const totalPagar = document.getElementById("totalPagar");

    listaCompras.innerHTML = "";
    comprasHospede.forEach(item => {
        const listItem = document.createElement("li");
        listItem.innerText = `${item.nome} - R$ ${item.preco.toFixed(2)}`;
        listaCompras.appendChild(listItem);
    });
    totalPagar.innerText = `Total a Pagar: R$ ${totalCompras.toFixed(2)}`;
}

function finalizarConsumo() {
    const nomeHospede = prompt("Insira seu nome para finalizar o consumo:");
    if (!nomeHospede) return;

    let frigobarHospede = JSON.parse(localStorage.getItem("frigobarHospede")) || {};

    if (!frigobarHospede[nomeHospede]) {
        frigobarHospede[nomeHospede] = [];
    }

    frigobarHospede[nomeHospede] = frigobarHospede[nomeHospede].concat(comprasHospede);

    localStorage.setItem("frigobarHospede", JSON.stringify(frigobarHospede));
    alert("Consumo finalizado.");
}

window.onload = carregarFrigobar;