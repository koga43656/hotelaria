function carregarHistorico() {
    const historicoCheckouts = JSON.parse(localStorage.getItem("historicoCheckouts")) || [];
    const tabela = document.getElementById("tabelaHistorico").getElementsByTagName("tbody")[0];
    tabela.innerHTML = "";


    historicoCheckouts.forEach(reserva => {
        const row = tabela.insertRow();
        row.insertCell(0).innerText = reserva.nomeUsuario;
        row.insertCell(1).innerText = reserva.numeroQuarto;
        row.insertCell(2).innerText = reserva.dataCheckin;
        row.insertCell(3).innerText = reserva.dataCheckout;
        row.insertCell(4).innerText = reserva.tipoReserva;
        row.insertCell(5).innerText = reserva.nomeResponsavel;
    });
}


        window.onload = carregarHistorico;