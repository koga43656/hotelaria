async function gerarHashSHA256(texto) {
    const encoder = new TextEncoder();
    const data = encoder.encode(texto);
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    return Array.from(new Uint8Array(hashBuffer))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
}

class ReservaBase {
    constructor() {
        this.reservas = JSON.parse(localStorage.getItem("reservas")) || [];
    }

    carregarUsuarios() {
        return JSON.parse(localStorage.getItem("usuarios")) || [];
    }

    carregarGerentes() {
        return JSON.parse(localStorage.getItem("gerentes")) || [];
    }

    carregarFuncionarios(){
        return JSON.parse(localStorage.getItem("funcionarios")) || [];
    }

    salvarReservas() {
        localStorage.setItem("reservas", JSON.stringify(this.reservas));
    }

    atribuirNumeroQuarto(tipoQuarto) {
        const quartosReservados = this.reservas.map(reserva => reserva.numeroQuarto);
        let numeroQuarto = 0;

        switch (tipoQuarto) {
            case "100":
                for (let i = 101; i <= 130; i++) {
                    if (!quartosReservados.includes(i)) {
                        numeroQuarto = i;
                        break;
                    }
                }
                break;
            case "200":
                for (let i = 201; i <= 230; i++) {
                    if (!quartosReservados.includes(i)) {
                        numeroQuarto = i;
                        break;
                    }
                }
                break;
            case "400":
                for (let i = 301; i <= 330; i++) {
                    if (!quartosReservados.includes(i)) {
                        numeroQuarto = i;
                        break;
                    }
                }
                break;
            default:
                alert("Tipo de quarto inválido.");
                return null;
        }

        if (numeroQuarto === 0) {
            alert(`Não há mais quartos disponíveis para o tipo ${tipoQuarto}`);
            return null;
        }

        return numeroQuarto;
    }

    validarDatas(dataCheckin, dataCheckout) {
        const checkinDate = new Date(dataCheckin);
        const checkoutDate = new Date(dataCheckout);
        const diasEstadia = (checkoutDate - checkinDate) / (1000 * 60 * 60 * 24);

        if (diasEstadia <= 0) {
            alert("A data de check-out deve ser posterior à data de check-in.");
            return null;
        }

        return diasEstadia;
    }

    calcularValorTotal(tipoQuarto, diasEstadia) {
        return parseFloat(tipoQuarto) * diasEstadia;
    }

    atualizarTabelaReservas() {
        const tabela = document.getElementById("listaReservas").getElementsByTagName("tbody")[0];
        if (!tabela) return;

        tabela.innerHTML = ""; // Limpa o conteúdo atual da tabela

        this.reservas.forEach((reserva, index) => {
            const row = tabela.insertRow();
            row.insertCell(0).innerText = reserva.nomeUsuario;
            row.insertCell(1).innerText = reserva.idUsuario;
            row.insertCell(2).innerText = reserva.emailUsuario;
            row.insertCell(3).innerText = reserva.tipoQuarto;
            row.insertCell(4).innerText = reserva.numeroQuarto;
            row.insertCell(5).innerText = reserva.dataCheckin;
            row.insertCell(6).innerText = reserva.dataCheckout;
            row.insertCell(7).innerText = `R$ ${reserva.valorTotal.toFixed(2).replace('.', ',')}`;
            row.insertCell(8).innerText = reserva.tipoReserva;

            // Coluna de ações (botão de remover)
            const acaoCell = row.insertCell(9);
            const botaoRemover = document.createElement("button");
            botaoRemover.innerText = "Remover";
            botaoRemover.onclick = () => this.removerReserva(index);
            acaoCell.appendChild(botaoRemover);
        });
    }

    removerReserva(index) {
        this.reservas.splice(index, 1);
        this.salvarReservas();
        this.atualizarTabelaReservas();
    }
}

// Classe para Reservas feitas pelo Gerente
class ReservaGerente extends ReservaBase {
    adicionarReserva() {
        const nomeUsuario = document.getElementById("nomeUsuarioReserva").value.trim();
        const idUsuario = parseInt(document.getElementById("idUsuarioReserva").value, 10);
        const emailUsuario = document.getElementById("emailUsuarioReserva").value.trim();
        const tipoQuarto = document.getElementById("tipoQuarto").value;
        const numeroQuarto = this.atribuirNumeroQuarto(tipoQuarto);

        if (numeroQuarto === null) return;

        const dataCheckin = document.getElementById("dataCheckin").value;
        const dataCheckout = document.getElementById("dataCheckout").value;

        if (!nomeUsuario || isNaN(idUsuario) || !emailUsuario || !tipoQuarto || !dataCheckin || !dataCheckout) {
            alert("Por favor, preencha todos os campos corretamente!");
            return;
        }

        if (!dataCheckin || !dataCheckout) {
            alert("Por favor, preencha as datas de check-in e check-out.");
            return;
        }

        const usuario = this.carregarUsuarios();
        const usuarioEncontrado = usuario.find(user => 
            user.nome === nomeUsuario && 
            user.id === idUsuario &&
            user.email === emailUsuario  
          
        );
    

        if (!usuarioEncontrado) {
            alert("Usuário não encontrado. Por favor, cadastre-se primeiro.");
            return;
        }

        const gerentes = this.carregarGerentes();
        const funcionarios = this.carregarFuncionarios()
        const responsavel = prompt("Digite o nome do gerente responsável por essa reserva:");
        if (!gerentes.some(g => g.nome === responsavel) && !funcionarios.some(f => f.nome === responsavel)) {
            alert("O nome fornecido não está registrado como gerente ou funcionário. Reserva não permitida.");
            return;
        
        }

        const diasEstadia = this.validarDatas(dataCheckin, dataCheckout);
        if (diasEstadia === null) return;

        const valorTotal = this.calcularValorTotal(tipoQuarto, diasEstadia);

        this.reservas.push({
            nomeUsuario,
            idUsuario,
            emailUsuario,
            senhaUsuario: usuarioEncontrado.senha,
            tipoQuarto,
            numeroQuarto,
            dataCheckin,
            dataCheckout,
            valorTotal,
            tipoReserva: `Presencial (${responsavel})`
        });

        this.salvarReservas();
        this.atualizarTabelaReservas();
        alert("Reserva cadastrada com sucesso!");
        document.getElementById("formReserva").reset();
    }
}

// Classe para Reservas feitas pelo Usuário
class ReservaUsuario extends ReservaBase {
    confirmarCadastro() {
        if (confirm("Tem certeza de que deseja fazer o cadastro?")) {
            this.verificarSenhaUsuario();
        }
    }

    async verificarSenhaUsuario() {
        const nomeUsuario = document.getElementById("nomeUsuario").value.trim();
        const senhaUsuario = document.getElementById("senhaUsuario").value.trim();
        const usuarios = this.carregarUsuarios();
    
        
        const senhaHash = await gerarHashSHA256(senhaUsuario);
    
     
        const usuarioEncontrado = usuarios.find(user => user.nome === nomeUsuario && user.senha === senhaHash);
    
        if (!usuarioEncontrado) {
            alert("Nome de usuário ou senha incorretos!");
            return;
        }
    
        this.adicionarReserva(usuarioEncontrado);
    }

    adicionarReserva(usuario) {
        const tipoQuarto = document.getElementById("tipoQuarto").value;
        const numeroQuarto = this.atribuirNumeroQuarto(tipoQuarto);

        if (numeroQuarto === null) return;


        const dataCheckin = document.getElementById("dataCheckinQuarto").value;
        const dataCheckout = document.getElementById("dataCheckoutQuarto").value;

        if (!dataCheckin || !dataCheckout) {
            alert("Por favor, preencha as datas de check-in e check-out.");
            return;
        }

        const diasEstadia = this.validarDatas(dataCheckin, dataCheckout);
        if (diasEstadia === null) return;

        const valorTotal = this.calcularValorTotal(tipoQuarto, diasEstadia);

        this.reservas.push({
            nomeUsuario: usuario.nome,
            idUsuario: usuario.id,
            emailUsuario: usuario.email,
            senhaUsuario: usuario.senha,
            tipoQuarto,
            numeroQuarto,
            dataCheckin,
            dataCheckout,
            valorTotal,
            tipoReserva: `Online`
        });

        this.salvarReservas();
        alert("Reserva cadastrada com sucesso!");
        document.getElementById("formReservaQuarto").reset();
        window.location.href = "indexhospede.html";
    }
}

const reservaGerente = new ReservaGerente();
const reservaUsuario = new ReservaUsuario();

// Atualizando a tabela de reservas quando a página for carregada
window.onload = function() {
    reservaGerente.atualizarTabelaReservas();
};