CREATE DATABASE bancodedados;
USE bancodedados;
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

INSERT INTO usuarios (nome) VALUES ('João');
INSERT INTO usuarios (nome) VALUES ('Maria');
INSERT INTO usuarios (nome) VALUES ('Pedro');

SELECT * FROM usuarios;


