from models.database import Database

class AppController:
    def __init__(self, app):
        self.db = Database(app)

    def pegar_dados(self):
        return self.db.pegar_todos_os_dados()
