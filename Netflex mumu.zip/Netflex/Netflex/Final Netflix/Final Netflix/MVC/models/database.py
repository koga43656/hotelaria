from flask_mysqldb import MySQL
from flask import Flask

class Database:
    def __init__(self, app: Flask):
        self.mysql = MySQL(app)

    def pegar_todos_os_dados(self):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM usuarios")
        data = cur.fetchall()
        return data

