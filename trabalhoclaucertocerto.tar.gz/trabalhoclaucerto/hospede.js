function carregarReservas() {
    const reservas = JSON.parse(localStorage.getItem("reservas")) || [];
    console.log("Reservas carregadas:", reservas);
    return reservas;
}


function atualizarTabelaReservas() {
    const tabela = document.getElementById("listaReservas").getElementsByTagName("tbody")[0];
    tabela.innerHTML = ""; 

    const reservas = carregarReservas();
    if (reservas.length === 0) {
        console.log("Nenhuma reserva encontrada.");
    }

    reservas.forEach((reserva, index) => {
        const row = tabela.insertRow();
        row.insertCell(0).innerText = reserva.nomeUsuario;
        row.insertCell(1).innerText = reserva.emailUsuario;
        row.insertCell(2).innerText = reserva.idUsuario;
        row.insertCell(3).innerText = reserva.numeroQuarto;


       
        const acaoCell = row.insertCell(4);
        const botaoRemover = document.createElement("button");
        botaoRemover.innerText = "Remover";
        botaoRemover.onclick = () => removerReserva(index);
        acaoCell.appendChild(botaoRemover);
    });
}


function removerReserva(index) {
    const reservas = carregarReservas();
    reservas.splice(index, 1);
    localStorage.setItem("reservas", JSON.stringify(reservas));
    console.log("Reserva removida. Atualizando a tabela...");
    atualizarTabelaReservas();
}


window.onload = atualizarTabelaReservas;