function calcularContas() {
    const nomeHospede = document.getElementById("nomeHospede").value.trim();
    const detalhesGastos = document.getElementById("detalhesGastos");
    detalhesGastos.innerHTML = "";

    if (!nomeHospede) {
        alert("Por favor, insira o nome do hóspede.");
        return;
    }

    const servicosHospede = JSON.parse(localStorage.getItem("servicosHospede")) || {};
    const frigobarHospede = JSON.parse(localStorage.getItem("frigobarHospede")) || {};
    const reservas = JSON.parse(localStorage.getItem("reservas")) || [];

    const servicos = servicosHospede[nomeHospede] || [];
    const frigobar = frigobarHospede[nomeHospede] || [];
    const reservaEncontrada = reservas.find(reserva => reserva.nomeUsuario === nomeHospede);

    let totalServicos = 0;
    servicos.forEach(servico => {
        detalhesGastos.innerHTML += `<li>Serviço: ${servico.nome} - R$ ${servico.preco.toFixed(2)}</li>`;
        totalServicos += servico.preco;
    });

    let totalFrigobar = 0;
    frigobar.forEach(item => {
        detalhesGastos.innerHTML += `<li>Frigobar: ${item.nome} - R$ ${item.preco.toFixed(2)}</li>`;
        totalFrigobar += item.preco;
    });

    let totalDiarias = 0;
    if (reservaEncontrada) {
        totalDiarias = reservaEncontrada.valorTotal || 0;
        detalhesGastos.innerHTML += `<li id="linhaDiarias">Diárias: R$ ${totalDiarias.toFixed(2)}</li>`; // Adiciona um ID à linha
    }

    const totalGeral = totalServicos + totalFrigobar + totalDiarias;
    document.getElementById("totalConta").innerText = `R$ ${totalGeral.toFixed(2)}`;

    const btnPagamento = document.getElementById("btnPagamento");
    const formPagamento = document.getElementById("formPagamento");
    if (totalGeral > 0) {
        btnPagamento.style.display = "none"; 
        formPagamento.style.display = "block"; 
    } else {
        btnPagamento.style.display = "none"; 
        formPagamento.style.display = "none"; 
    }
}

function pagar() {
    const formaPagamento = document.getElementById("formaPagamento").value;
    const senhaCartao = document.getElementById("senhaCartao").value;
    const nomeHospede = document.getElementById("nomeHospede").value.trim();
    const totalGeral = parseFloat(document.getElementById("totalConta").innerText.replace("R$ ", "").replace(",", "."));

    if (formaPagamento && senhaCartao) {
      
        document.getElementById("totalConta").innerText = `R$ 0,00`;

     
        const linhaDiarias = document.getElementById("linhaDiarias");
        if (linhaDiarias) {
            linhaDiarias.remove();
        }

     
        let reservas = JSON.parse(localStorage.getItem("reservas")) || [];
        const reservaIndex = reservas.findIndex(reserva => reserva.nomeUsuario === nomeHospede);

        if (reservaIndex !== -1) {
            reservas[reservaIndex].valorTotal = 0;
            localStorage.setItem("reservas", JSON.stringify(reservas));
        }

        alert("Pagamento realizado com sucesso!");
        document.getElementById("formPagamento").style.display = "none";
    } else {
        alert("Por favor, preencha todos os campos de pagamento.");
    }
}