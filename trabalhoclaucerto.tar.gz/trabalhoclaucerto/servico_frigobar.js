class Produto {
    constructor(id, nome, preco) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
    }
}

class ProdutoManager {
    constructor() {
        this.produtosIniciais = [
            new Produto(1, "Coca Cola", 5.50),
            new Produto(2, "Chocolate", 10.00),
            new Produto(3, "Guaraná", 4.50),
            new Produto(4, "Vinho", 50.00)
        ];
    }

    inicializarProdutos() {
        const produtos = this.carregarProdutos();
        if (produtos.length === 0) {
            this.salvarProdutos(this.produtosIniciais);
        }
        this.atualizarTabelaProdutos();
    }

    carregarProdutos() {
        return JSON.parse(localStorage.getItem("produtosFrigobar")) || [];
    }

    salvarProdutos(produtos) {
        localStorage.setItem("produtosFrigobar", JSON.stringify(produtos));
    }

    adicionarProduto(id, nome, preco) {
        if (!id || !nome || isNaN(preco)) {
            alert("Por favor, preencha todos os campos corretamente!");
            return;
        }

        const produtos = this.carregarProdutos();

    

        const idExistente = produtos.some(servico => servico.id === id);
        const nomeExistente = produtos.some(servico => servico.nome === nome);
    
        if (idExistente) {
            alert("O ID do produto já existe. Por favor, escolha outro ID.");
            return;
        }
    
        if (nomeExistente) {
            alert("Já existe um produto com esse nome. Por favor, escolha outro nome.");
            return;
        }
        produtos.push(new Produto(id, nome, preco));
        this.salvarProdutos(produtos);
        this.atualizarTabelaProdutos();
    }

    removerProduto(index) {
        const produtos = this.carregarProdutos();
        produtos.splice(index, 1);
        this.salvarProdutos(produtos);
        this.atualizarTabelaProdutos();
    }

    atualizarTabelaProdutos() {
        const tabela = document.getElementById("listaFrigobar").getElementsByTagName("tbody")[0];
        tabela.innerHTML = "";

        const produtos = this.carregarProdutos();
        produtos.forEach((produto, index) => {
            const row = tabela.insertRow();
            row.insertCell(0).innerText = produto.id;
            row.insertCell(1).innerText = produto.nome;
            row.insertCell(2).innerText = `R$ ${produto.preco.toFixed(2)}`;

            const acaoCell = row.insertCell(3);
            const botaoRemover = document.createElement("button");
            botaoRemover.innerText = "Remover";
            botaoRemover.onclick = () => this.removerProduto(index);
            acaoCell.appendChild(botaoRemover);
        });
    }
}

class Servico {
    constructor(id, nome, preco) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
    }
}

class ServicoManager {
    constructor() {
        this.servicosIniciais = [
            new Servico(1, "Massagem", 80.00),
            new Servico(2, "Spa", 150.00),
            new Servico(3, "Passeio de barco", 200.00),
            new Servico(4, "Trilha", 50.00)
        ];
    }

    inicializarServicos() {
        const servicos = this.carregarServicos();
        if (servicos.length === 0) {
            this.salvarServicos(this.servicosIniciais);
        }
        this.atualizarTabelaServicos();
    }

    carregarServicos() {
        return JSON.parse(localStorage.getItem("servicos")) || [];
    }

    salvarServicos(servicos) {
        localStorage.setItem("servicos", JSON.stringify(servicos));
    }

    adicionarServico(id, nome, preco) {
        if (!id || !nome || isNaN(preco)) {
            alert("Por favor, preencha todos os campos corretamente!");
            return;
        }

        const servicos = this.carregarServicos();

        const idExistente = servicos.some(servico => servico.id === id);
        const nomeExistente = servicos.some(servico => servico.nome === nome);
    
        if (idExistente) {
            alert("O ID do serviço já existe. Por favor, escolha outro ID.");
            return;
        }
    
        if (nomeExistente) {
            alert("Já existe um serviço com esse nome. Por favor, escolha outro nome.");
            return;
        }

        servicos.push(new Servico(id, nome, preco));
        this.salvarServicos(servicos);
        this.atualizarTabelaServicos();
    }

    removerServico(index) {
        const servicos = this.carregarServicos();
        servicos.splice(index, 1);
        this.salvarServicos(servicos);
        this.atualizarTabelaServicos();
    }

    atualizarTabelaServicos() {
        const tabela = document.getElementById("listaServicos").getElementsByTagName("tbody")[0];
        tabela.innerHTML = "";

        const servicos = this.carregarServicos();
        servicos.forEach((servico, index) => {
            const row = tabela.insertRow();
            row.insertCell(0).innerText = servico.id;
            row.insertCell(1).innerText = servico.nome;
            row.insertCell(2).innerText = `R$ ${servico.preco.toFixed(2)}`;

            const acaoCell = row.insertCell(3);
            const botaoRemover = document.createElement("button");
            botaoRemover.innerText = "Remover";
            botaoRemover.onclick = () => this.removerServico(index);
            acaoCell.appendChild(botaoRemover);
        });
    }
}

// Instancia os gerenciadores
const produtoManager = new ProdutoManager();
const servicoManager = new ServicoManager();

// Inicializa os dados ao carregar a página


// Funções para manipular produtos e serviços
function adicionarProdutoHandler(event) {
    event.preventDefault();
    const id = Number(document.getElementById("idProduto").value);
    const nome = document.getElementById("nomeProduto").value;
    const preco = parseFloat(document.getElementById("precoProduto").value);
    produtoManager.adicionarProduto(id, nome, preco);
    document.getElementById("formFrigobar").reset();
}

function adicionarServicoHandler(event) {
    event.preventDefault();
    const id = Number(document.getElementById("idServico").value);
    const nome = document.getElementById("nomeServico").value;
    const preco = parseFloat(document.getElementById("precoServico").value);
    servicoManager.adicionarServico(id, nome, preco);
    document.getElementById("formServico").reset();
}

window.onload = () => {
    
    try {
        servicoManager.inicializarServicos();
    } catch (error) {
        console.error("Erro ao inicializar Servicos:", error);
    }

    try {
        produtoManager.inicializarProdutos();
    } catch (error) {
        console.error("Erro ao inicializar produtos:", error);
    }
};
