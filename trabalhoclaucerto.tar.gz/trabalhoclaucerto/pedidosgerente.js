const pedidos = JSON.parse(localStorage.getItem("pedidos")) || [];
const funcionarios = JSON.parse(localStorage.getItem("funcionarios")) || [];

function carregarPedidos() {
    const tabela = document.getElementById("listaPedidos");
    tabela.innerHTML = "";

    pedidos.forEach((pedido, index) => {
        const row = tabela.insertRow();
        row.insertCell(0).innerText = pedido.cliente;
        row.insertCell(1).innerText = pedido.servico;
        row.insertCell(2).innerText = pedido.numeroQuarto;


        const acaoCell = row.insertCell(3);
        const botaoEnviar = document.createElement("button");
        botaoEnviar.innerText = "Enviar Funcionário";
        botaoEnviar.onclick = () => enviarFuncionario(index);
        acaoCell.appendChild(botaoEnviar);
    });
}

function enviarFuncionario(index) {
    const nomeFuncionario = prompt("Digite o nome do funcionário para realizar o serviço:");
    if (!nomeFuncionario) {
        alert("Nome do funcionário é obrigatório!");
        return;
    }

    const funcionarioExiste = funcionarios.some(funcionario => funcionario.nome === nomeFuncionario);
    if (!funcionarioExiste) {
        alert("Funcionário não encontrado na lista. Ação não permitida.");
        return;
    }

    alert(`Pedido de "${pedidos[index].servico}" será atendido por ${nomeFuncionario}.`);
    pedidos.splice(index, 1);
    localStorage.setItem("pedidos", JSON.stringify(pedidos));
    carregarPedidos();
}

window.onload = carregarPedidos;