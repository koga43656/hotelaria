let reservas = JSON.parse(localStorage.getItem("reservas")) || [];


function carregarHospedesParaCheckout() {
    const tabela = document.getElementById("listaCheckout").getElementsByTagName("tbody")[0];
    tabela.innerHTML = "";
    reservas.forEach((reserva, index) => {
        const row = tabela.insertRow();
        row.insertCell(0).innerText = reserva.nomeUsuario;
        row.insertCell(1).innerText = reserva.numeroQuarto
        row.insertCell(2).innerText = reserva.dataCheckin;
        row.insertCell(3).innerText = reserva.dataCheckout;


       
        const valorTotal = reserva.valorTotal.toFixed(2);
        row.insertCell(4).innerText = `R$ ${valorTotal}`;


        const acaoCell = row.insertCell(5);
        const botaoVerConta = document.createElement("button");
        botaoVerConta.innerText = "Ver Conta";
        botaoVerConta.onclick = () => {
         
            window.location.href = `contasfuncionario.html?nomeHospede=${encodeURIComponent(reserva.nomeUsuario)}`;
        };
        acaoCell.appendChild(botaoVerConta);
    });
}


function encerrarEstadia() {
const nomeHospede = document.getElementById("nomeHospedeCheckout").value.trim();


if (!nomeHospede) {
    alert("Por favor, insira o nome do hóspede.");
    return;
}



const nomeResponsavel = prompt("Digite o nome do gerente ou funcionário responsável pelo check-out:");
const gerentes = JSON.parse(localStorage.getItem("gerentes")) || [];
const responsavelValido = gerentes.some(g => g.nome === nomeResponsavel);


if (!responsavelValido) {
    alert("O nome fornecido não está registrado como gerente ou funcionário. Check-out não permitido.");
    return;
}


let reservas = JSON.parse(localStorage.getItem("reservas")) || [];
const index = reservas.findIndex(reserva => reserva.nomeUsuario === nomeHospede);


if (index === -1) {
    alert("Hóspede não encontrado para check-out.");
    return;
}



const reservaFinalizada = reservas.splice(index, 1)[0];
reservaFinalizada.nomeResponsavel = nomeResponsavel;


let historicoCheckouts = JSON.parse(localStorage.getItem("historicoCheckouts")) || [];
historicoCheckouts.push(reservaFinalizada);


localStorage.setItem("reservas", JSON.stringify(reservas));
localStorage.setItem("historicoCheckouts", JSON.stringify(historicoCheckouts));


alert("Check-out realizado com sucesso!");
carregarHospedesParaCheckout();
}


function carregarHospedesParaCheckout() {
const tabela = document.getElementById("listaCheckout").getElementsByTagName("tbody")[0];
tabela.innerHTML = "";
const reservas = JSON.parse(localStorage.getItem("reservas")) || [];

reservas.forEach(reserva => {
    const row = tabela.insertRow();
    row.insertCell(0).innerText = reserva.nomeUsuario;
    row.insertCell(1).innerText = reserva.numeroQuarto;
    row.insertCell(2).innerText = reserva.dataCheckin;
    row.insertCell(3).innerText = reserva.dataCheckout;
    row.insertCell(4).innerText = `R$ ${reserva.valorTotal.toFixed(2).replace('.', ',')}`;


    const acaoCell = row.insertCell(5);
        const botaoVerConta = document.createElement("button");
        botaoVerConta.innerText = "Ver Conta";
        botaoVerConta.onclick = () => {
         
            window.location.href = `contasfuncionario.html?nomeHospede=${encodeURIComponent(reserva.nomeUsuario)}`;
        };
        acaoCell.appendChild(botaoVerConta);
});
}


window.onload = carregarHospedesParaCheckout;